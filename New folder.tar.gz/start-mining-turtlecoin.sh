#!/bin/sh

#This is an example you can edit and use
#There are numerous parameters you can set, please check Help and Examples folder

export GPU_MAX_HEAP_SIZE=100
export GPU_MAX_USE_SYNC_OBJECTS=1
export GPU_SINGLE_ALLOC_PERCENT=100
export GPU_MAX_ALLOC_PERCENT=100
export GPU_MAX_SINGLE_ALLOC_PERCENT=100
export GPU_ENABLE_LARGE_ALLOCATION=100
export GPU_MAX_WORKGROUP_SIZE=1024

./SRBMiner-MULTI --panthera --de.scala.herominers.com:1190 --wallet Ssy2QY4RhfTYA9x1bThco1VJ54nEzFDr3dbHuzVVFbtAYfvoo1gCyDwd6taSsb2wKPCUJfHhFXBqdKQUswaFXFksAM5FNofyqL --gpu-boost 3
